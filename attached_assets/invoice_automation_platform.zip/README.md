
# BlueCHP Invoice Automation Platform

This project ZIP contains a business case, detailed requirements, UI/UX wireframes, plug-in code stubs, and bulk upload tooling for your modular invoice automation platform (UniPhi, BASIX, Outlook integration).

**Folders:**
- `/docs` – Business case, requirements matrix
- `/src` – Code stubs, plugin templates, UI wireframes
- `/config` – Sample config for feature flags and integration
