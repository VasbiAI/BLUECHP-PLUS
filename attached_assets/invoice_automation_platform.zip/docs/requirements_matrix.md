
# Requirements Matrix – Invoice Automation Platform

| Req ID | Category         | Description                                                                            | Must/Should | Phase | Related Module           | Notes                                  |
|--------|------------------|----------------------------------------------------------------------------------------|-------------|-------|--------------------------|----------------------------------------|
| R1     | Intake           | Upload invoices via dedicated Outlook inbox                                            | Must        | 1     | Email Intake Module      | Microsoft Graph API                    |
| R2     | Intake           | Manual and bulk upload via web UI (drag-drop/ZIP)                                     | Must        | 1     | Manual Upload Module     |                                        |
| R3     | Document Parsing | OCR extraction of invoice fields (supplier, ABN, PO, total, etc)                      | Must        | 1     | Document Extraction      | OpenAI, Azure, or Google Vision        |
| R4     | Matching         | Match PO/project to UniPhi system (plugin)                                            | Must        | 1     | UniPhi Plugin            |                                        |
| R5     | Matching         | Fallback: match PO/project to BASIX system (plugin)                                   | Must        | 2     | BASIX Plugin             |                                        |
| R6     | Workflow         | Exception handling UI for unmatched/problem invoices                                  | Must        | 1     | Exception UI             | Editable, variance detection           |
| R7     | Workflow         | Approval routing per financial delegation levels                                      | Must        | 1     | Approval Routing         | Multi-level, escalation                |
| R8     | Vendor Comm      | Auto-generate replies via Outlook to vendor (decline, info request, etc.)             | Should      | 2     | Vendor Communication     | Template-based                         |
| R9     | Learning         | Human-in-the-loop correction and continuous AI/OCR improvement                        | Should      | 2     | Document Extraction      | Annotate, retrain                      |
| R10    | Reporting        | Dashboard for management (status, forecasts, exceptions)                              | Must        | 2     | Reporting                | Charts, export                         |
| R11    | Security         | RBAC, OAuth2 SSO, secure data at rest and in transit                                  | Must        | 1     | Authentication/Security  |                                        |
| R12    | Logging          | Audit log for all actions, approvals, changes                                         | Must        | 1     | Audit Trail              |                                        |
| R13    | Bulk Upload      | Scripted CLI and/or ZIP upload support for testing and backfill                       | Should      | 1     | Bulk Upload Tool         |                                        |
| R14    | Plugin Config    | Enable/disable modules (UniPhi, BASIX, Email, Manual, Reporting) via feature flags     | Must        | 1     | Config/Plugin Loader     | For phased/staged rollout              |
| R15    | Scalability      | Easily extendable to new project/accounting systems via plugin pattern                | Should      | 2     | Plugin Loader            |                                        |
| R16    | Exception Types  | UI and logic for over/under PO, unmatched, multi-PO, and non-PO invoices              | Must        | 2     | Exception Handler        |                                        |
| R17    | Testing          | Automated tests and bulk validation using real historical invoices                     | Must        | 1     | Testing/QA               | Human-in-the-loop annotation           |
