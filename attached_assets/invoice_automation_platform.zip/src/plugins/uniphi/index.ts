
// UniPhi Plugin Interface Example

export interface InvoiceData {
    supplier: string;
    abn: string;
    poNumber?: string;
    amount: number;
    // ... more fields as needed
}

export interface UniPhiPlugin {
    matchPO(invoice: InvoiceData): Promise<{ matched: boolean; projectId?: string; reason?: string; }>;
    fetchProjects(): Promise<{ id: string; name: string; }[]>;
    submitForApproval(invoice: InvoiceData): Promise<{ status: string; referenceId?: string; }>;
}

// Export example implementation or stub
export const uniphiPlugin: UniPhiPlugin = {
    async matchPO(invoice) {
        // ...call UniPhi API to match
        return { matched: false, reason: "stub" };
    },
    async fetchProjects() {
        // ...fetch from UniPhi
        return [];
    },
    async submitForApproval(invoice) {
        // ...submit to UniPhi
        return { status: "submitted" };
    },
};
