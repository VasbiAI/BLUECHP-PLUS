
// BASIX Plugin Interface Example

export interface InvoiceData {
    supplier: string;
    abn: string;
    poNumber?: string;
    amount: number;
    // ... more fields as needed
}

export interface BasixPlugin {
    matchPO(invoice: InvoiceData): Promise<{ matched: boolean; projectId?: string; reason?: string; }>;
    fetchProjects(): Promise<{ id: string; name: string; }[]>;
    submitForApproval(invoice: InvoiceData): Promise<{ status: string; referenceId?: string; }>;
}

export const basixPlugin: BasixPlugin = {
    async matchPO(invoice) {
        // ...call BASIX API to match
        return { matched: false, reason: "stub" };
    },
    async fetchProjects() {
        // ...fetch from BASIX
        return [];
    },
    async submitForApproval(invoice) {
        // ...submit to BASIX
        return { status: "submitted" };
    },
};
