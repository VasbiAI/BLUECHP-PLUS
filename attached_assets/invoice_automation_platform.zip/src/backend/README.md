
# Backend Integration Points

- `/api/documents/upload` — Intake endpoint for invoices (manual, bulk, email)
- `plugins/uniphi/` — UniPhi plug-in for PO/project matching and approval
- `plugins/basix/` — BASIX plug-in for PO/project matching and approval
- Bulk upload script (`bulk_upload_example.py`) for initial AI/OCR training and testing
