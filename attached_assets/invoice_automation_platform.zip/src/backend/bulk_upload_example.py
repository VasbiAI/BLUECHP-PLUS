
# Bulk Upload Script Example

import requests, os

API_URL = "https://yourapp/api/documents/upload"
INVOICE_DIR = "path_to_your_invoices"

for filename in os.listdir(INVOICE_DIR):
    if filename.lower().endswith(('.pdf', '.jpg', '.png')):
        with open(os.path.join(INVOICE_DIR, filename), 'rb') as file:
            files = {'file': (filename, file)}
            response = requests.post(API_URL, files=files)
            print(f"{filename}: {response.status_code} {response.text}")
