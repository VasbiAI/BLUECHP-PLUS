
# Exception Handler UI Mockup

-------------------------------------------------------------
| Invoice Exception Handler                                 |
-------------------------------------------------------------
| [Invoice PDF/Image]     | [Extracted Fields]              |
|-------------------------|---------------------------------|
|  [Preview]              |  Supplier:      [_____]         |
|                         |  ABN:           [_____]         |
|                         |  Invoice #:      [_____]        |
|                         |  PO #:           [_____]        |
|                         |  System:        [UniPhi/BASIX]  |
|                         |  Amount:         [_____]        |
|                         |  Matched Project:[_____]        |
|                         |  Status:         [Exception]    |
|-------------------------|---------------------------------|
| [Variance Panel if PO]                                   |
|  PO Value: $xx,xxx  Invoiced: $xx,xxx   Delta: $xxx      |
|  [Escalate approval if needed]                           |
-------------------------------------------------------------
| [Actions:]                                                |
|  [Approve] [Escalate] [Assign to UniPhi] [Assign to BASIX]|
|  [Link to Different PO] [Comment] [Reply to Vendor]       |
-------------------------------------------------------------
| [Audit Log]                                               |
-------------------------------------------------------------
